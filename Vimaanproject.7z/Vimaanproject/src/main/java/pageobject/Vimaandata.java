package pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Vimaandata {

	public WebDriver driver;
	

	By Email=By.id("mat-input-0");
	By Password=By.id("mat-input-1");
	By Login=By.className("mat-button-wrapper");
	By Menu=By.id("menu-list-icon");
	By Report=By.xpath("//mat-nav-list[@id='side-nav-bar']/div[2]/div/a/div/span");
	By Repoclick=By.id("mat-input-3");
	By Locationsearch=By.xpath("//mat-nav-list[@id='side-nav-bar']/div[2]/a[2]/div/span");
	
	
	
	public Vimaandata(WebDriver driver) {  //created constructor to give life to the driver
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}

	public WebElement getemail()
	{
		return driver.findElement(Email);
	}
	public WebElement getpassword()
	{
		return driver.findElement(Password);
	}
	public WebElement clicklogin()
	{
		return driver.findElement(Login);
	}
	public WebElement clickmenu()
	{
		return driver.findElement(Menu);
	}
	public WebElement clickreport()
	{
		return driver.findElement(Report);
	}
	public WebElement getrepoclick()
	{
		return driver.findElement(Repoclick);
	}
	public WebElement getrepolocationsearch()
	{
		return driver.findElement(Locationsearch);
	}


}

