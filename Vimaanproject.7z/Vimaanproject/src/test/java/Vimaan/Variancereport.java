package Vimaan;

import javaresources.base;
import org.apache.logging.log4j.LogManager;

import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;


import pageobject.Vimaandata;

public class Variancereport<driver> extends base{
	
	public WebDriver driver;
	public static Logger Log=LogManager.getLogger(base.class.getName()); 

	@BeforeTest 
	public void  intialisedrive() throws IOException
	{
	driver=initializeDriver();

	}
	@Test()
	public void Variance() throws IOException, InterruptedException
	{
    driver.get(prop.getProperty("VimaanDashboard"));
    Vimaandata vd=new Vimaandata(driver);
	vd.getemail().sendKeys(prop.getProperty("Username"));
	vd.getpassword().sendKeys(prop.getProperty("Password"));
	Thread.sleep(2000);
	vd.clicklogin().click();
	Thread.sleep(2000);
	vd.clickmenu().click();
	Thread.sleep(2000);
	vd.clickreport().click();
	Thread.sleep(2000);
	vd.getrepoclick().click();

		
		 
		


	
}
}
	
	


